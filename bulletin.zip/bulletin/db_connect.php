<?php
$host = "localhost";
$user = "arthurnerritech_library";
$pass = "arthurtech_2025";
$db = "arthurnerritech_library";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
}
?> 